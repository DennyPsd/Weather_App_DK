package com.example.weatherappDK.fragments

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Bundle
import android.os.CancellationSignal
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.activityViewModels
import com.android.volley.DefaultRetryPolicy
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.bumptech.glide.Glide
import com.example.weatherappDK.DIalogManager
import com.example.weatherappDK.ManiViewModel
import com.example.weatherappDK.R
import com.example.weatherappDK.adapters.WeatherModel
import com.example.weatherappDK.adapters.vpAdapter
import com.example.weatherappDK.databinding.FragmentMainBinding
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.location.SettingsClient
import com.google.android.gms.tasks.CancellationToken
import com.google.android.gms.tasks.CancellationTokenSource
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale


const val API_KEY = "51337e83a6284b8ebf481810241610"

class MainFragment : Fragment() {

    private lateinit var fLocationClient: FusedLocationProviderClient


    private lateinit var pLauncher: ActivityResultLauncher<String>
    private lateinit var binding: FragmentMainBinding
    private val model:ManiViewModel by activityViewModels()

    //Подключение binding при создании
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentMainBinding.inflate(inflater, container, false)
        return binding.root
    }

    //Проверка разрешений и инициализация функции для слайдера. Запуск мэин функций
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        checkPermission()
        init()
        updateCurrentCard()
        //requestWeatherData("Omsk")
        getData()
    }


//Слайдер карточек
    //Массив для карточек прогноза Дни/Часы
    private val fList = listOf(
        DaysFragment.newInstance(),
        TapFragment.newInstance()

    )
    private val tList = listOf(
        HoursFragment.newInstance()
    )

    //Проверка разрешения на GPS
    private fun checkLocation(){
        if(isLocationEnabled()){
            getLocation()
        } else {
            DIalogManager.locationSettingsDialog(requireContext(), object : DIalogManager.Listener{
                override fun onClick(name: String?) {
                    startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                }
            })
        }
    }

    private fun isLocationEnabled(): Boolean{
        val lm = activity?.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
    }

    //Получение GPS
    private fun getLocation(){
//        if (!isLocationEnabled()){
//            Toast.makeText(requireContext(), "Location disabled", Toast.LENGTH_SHORT).show()
//            return
//        }
        val ct = CancellationTokenSource()
        if (ActivityCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        fLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, ct.token)
            .addOnCompleteListener{
                Log.d("","${it.result.latitude},${it.result.longitude}")
            requestWeatherData("${it.result.latitude},${it.result.longitude}")
        }
    }

    //Получение локации при разворачивании прилки
    override fun onResume() {
        super.onResume()
        checkLocation()
    }

    //Функция адаптера для слайдера
    private fun init() = with(binding){
        fLocationClient = LocationServices.getFusedLocationProviderClient(requireContext())
        val adapter = vpAdapter(activity as FragmentActivity, fList)
        vp.adapter = adapter
        dotsIndicator.setViewPager2(vp)

        val adapter2 = vpAdapter(activity as FragmentActivity, tList)
        vp2.adapter = adapter2

        ibSync.setOnClickListener{
            checkLocation()
        }
        ibSearch.setOnClickListener{
            DIalogManager.searchByNameDialog(requireContext(), object : DIalogManager.Listener{
                override fun onClick(name: String?) {
                    if (name != null) {
                        requestWeatherData(name)
                    }
                }
            })
        }
    }

    //Функция обновления данных на верхней карточке
    private fun updateCurrentCard() = with(binding){
        model.liveDataCurrent.observe(viewLifecycleOwner){
            tvDateMain.text = getData()
            //tvCountry.text = changeCity(it.city)
            tvCountry.text = it.city
            tvDeskr.text = changeDeskr(it.condition)
            tvTempMain.text = "${Math.round(it.currentTemp.toFloat())} ℃"
            gifLoader(changeDeskr(it.condition))

        }
    }

    //Функция перевода описания
    private fun changeDeskr(deskr: String):String{
        var nowDeskr = ""
        when (deskr.trim().lowercase()){
            "sunny" -> nowDeskr = "Солнечно"
            "clear" -> nowDeskr = "Ясно"
            "patchy rain nearby","light freezing rain" -> nowDeskr = "Местами дождь"
            "clouds", "cloudy", "partly cloudy" -> nowDeskr = "Облачно"
            "overcast" -> nowDeskr = "Пасмурно"
            "snow", "heavy snow","moderate snow","light snow" -> nowDeskr = "Снег"
        }
        return nowDeskr
    }

    //Функция перевода города
    private fun changeCity(city: String):String{
        var nowCity = ""
        when (city){
            "Omsk" -> nowCity = "Омск"
        }
        return nowCity
    }

    //Тестовая функция получения даты
    private fun getData(): String{
        var nowDay = ""
        var nowMonth = ""
        val dayOfWeek = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
        val day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
        val month = Calendar.getInstance().get(Calendar.MONTH)
        val year = Calendar.getInstance().get(Calendar.YEAR)
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val min = Calendar.getInstance().get(Calendar.MINUTE)

        when (dayOfWeek) {
            1 -> nowDay = "Воскресенье"
            2 -> nowDay = "Понедельник"
            3 -> nowDay = "Вторник"
            4 -> nowDay = "Среда"
            5 -> nowDay = "Четверг"
            6 -> nowDay = "Пятница"
            7 -> nowDay = "Суббота"
        }
        when(month){
            1 -> nowMonth = "Февраля"
            2 -> nowMonth = "Марта"
            3 -> nowMonth = "Апреля"
            4 -> nowMonth = "Мая"
            5 -> nowMonth = "Июня"
            6 -> nowMonth = "Июля"
            7 -> nowMonth = "Августа"
            8 -> nowMonth = "Сентября"
            9 -> nowMonth = "Октября"
            10 -> nowMonth = "Ноября"
            11 -> nowMonth = "Декабря"
            12 -> nowMonth = "Января"
        }

        return nowDay + ", " + day + " " + nowMonth
    }


    //Функция загрузки GIF по прогнозу ДОДЕЛАТЬ условия на каждое описание
    private fun gifLoader(condition: String) = with(binding){
        when (condition) {
            "Солнечно", "Ясно" ->  Glide.with(this@MainFragment).load(R.drawable.gif_clear).into(tvImageMain)
            "Местами дождь" ->  Glide.with(this@MainFragment).load(R.drawable.gif_mest_rain).into(tvImageMain)
            "Облачно" ->  Glide.with(this@MainFragment).load(R.drawable.gif_mest_obl).into(tvImageMain)
            "Пасмурно" ->  Glide.with(this@MainFragment).load(R.drawable.gif_obl).into(tvImageMain)
            "Снег" ->  Glide.with(this@MainFragment).load(R.drawable.gif_snow).into(tvImageMain)
        else -> {}
        }
    }

//Функции проверки разрешения местоположений
    //CallBack на ожидание ответа разрешений от пользователя
    private fun permissionListener(){
        pLauncher = registerForActivityResult(
            ActivityResultContracts.RequestPermission()){
            Toast.makeText(activity,"Permission it $it", Toast.LENGTH_LONG).show()
        }
    }

    //Проверка разрешения от пользователя
    private fun checkPermission(){
        if(!isPermissionGranted(android.Manifest.permission.ACCESS_FINE_LOCATION)){
            permissionListener()
            pLauncher.launch(android.Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    //Запрос погоды с API
    private fun requestWeatherData(city: String){
        val url = "https://api.weatherapi.com/v1/forecast.json?" +
                "key=$API_KEY" +
                "&q=$city" +
                "&days=7&aqi=no&alerts=no"
        val qeue = Volley.newRequestQueue(context)
        val request = StringRequest(
            Request.Method.GET,
            url,
            {
                result -> parseWeatherData(result)
            },
            {
                error -> Log.d("MyLog","$error")
            }
        )
        request.setRetryPolicy(DefaultRetryPolicy(5000, 2, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT))
        qeue.add(request)
    }

    //Парсинг JSON
    private fun parseWeatherData(result: String){
        val mainObject = JSONObject(result)
        val list = parseDays(mainObject)
        parseCurrentData(mainObject, list[0])
    }

    //Парсинг прогноза по дням
    private fun parseDays(mainObject: JSONObject): List<WeatherModel>{
        val list = ArrayList<WeatherModel>()
        val daysArray = mainObject.getJSONObject("forecast").getJSONArray("forecastday")
        val name = mainObject.getJSONObject("location").getString("name")
        for (i in 0 until daysArray.length()){
            val day = daysArray[i] as JSONObject
            val item = WeatherModel(
                name,
                day.getString("date"),
                day.getJSONObject("day").getJSONObject("condition").getString("text"),
                "",
                day.getJSONObject("day").getString("maxtemp_c"),
                day.getJSONObject("day").getString("mintemp_c"),
                day.getJSONObject("day").getJSONObject("condition").getString("icon"),
                day.getJSONArray("hour").toString()
            )
            list.add(item)
        }
        model.liveDataList.value = list
    return list
    }

    //Парсинг текущей погоды
    private fun parseCurrentData(mainObject: JSONObject, weatherItem: WeatherModel){
        val item = WeatherModel(
            mainObject.getJSONObject("location").getString("region"),
            mainObject.getJSONObject("location").getString("localtime"),
            mainObject.getJSONObject("current").getJSONObject("condition").getString("text"),
            mainObject.getJSONObject("current").getString("temp_c"),
            weatherItem.maxTemp,
            weatherItem.minTemp,
            "",
            weatherItem.hours
        )
        model.liveDataCurrent.value = item
        Log.d("MyLog",item.city)
    }

//Отображение фрагмента
    companion object {
        fun newInstance() = MainFragment()
    }


}